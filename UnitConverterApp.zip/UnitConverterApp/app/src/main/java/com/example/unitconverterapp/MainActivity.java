package com.example.unitconverterapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputValue;
    private Spinner fromUnit;
    private Spinner toUnit;
    private Switch switchUnits;
    private TextView resultView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputValue = findViewById(R.id.inputValue);
        fromUnit = findViewById(R.id.fromUnit);
        toUnit = findViewById(R.id.toUnit);
        switchUnits = findViewById(R.id.switchUnits);
        resultView = findViewById(R.id.resultView);
        Button convertButton = findViewById(R.id.convertButton);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convertUnits();
            }
        });

        switchUnits.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Swap the units in the spinners
            int fromPosition = fromUnit.getSelectedItemPosition();
            int toPosition = toUnit.getSelectedItemPosition();

            fromUnit.setSelection(toPosition);
            toUnit.setSelection(fromPosition);
        });
    }

    private void convertUnits() {
        double input = Double.parseDouble(inputValue.getText().toString());
        String from = fromUnit.getSelectedItem().toString();
        String to = toUnit.getSelectedItem().toString();

        double result = performConversion(input, from, to);

        if (Double.isNaN(result)) {
            resultView.setText("Conversion is not valid");
        } else {
            resultView.setText(String.valueOf(result));
        }
    }


    private double performConversion(double input, String from, String to) {
        // Check if conversion is between the same unit
        if (from.equals(to)) {
            return Double.NaN; // Return NaN to indicate invalid conversion
        }

        // Conversion logic here
        if (from.equals("Meters") && to.equals("Centimeters")) {
            return input * 100;
        } else if (from.equals("Centimeters") && to.equals("Meters")) {
            return input / 100;
        } else if (from.equals("Kilograms") && to.equals("Grams")) {
            return input * 1000;
        } else if (from.equals("Grams") && to.equals("Kilograms")) {
            return input / 1000;
        } else if (from.equals("Hours") && to.equals("Minutes")) {
            return input * 60;
        } else if (from.equals("Minutes") && to.equals("Hours")) {
            return input / 60;
        } else if (from.equals("Celsius") && to.equals("Kelvin")) {
            return input + 273.15;
        } else if (from.equals("Kelvin") && to.equals("Celsius")) {
            return input - 273.15;
        } else {
            return Double.NaN; // Return NaN for unsupported conversions
        }
    }
}